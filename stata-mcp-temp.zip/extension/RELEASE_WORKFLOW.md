# Release and Update Workflow Guide

**⚠️ PRIVATE FILE - FOR LOCAL USE ONLY**

This document contains step-by-step instructions for releasing new versions of the Stata MCP extension. Keep this file local and excluded from GitHub.

---

## Table of Contents

1. [Pre-Release Checklist](#pre-release-checklist)
2. [Version Bump Process](#version-bump-process)
3. [Building the Package](#building-the-package)
4. [Publishing Workflow](#publishing-workflow)
5. [Post-Release Tasks](#post-release-tasks)
6. [Troubleshooting](#troubleshooting)
7. [Credentials and Tokens](#credentials-and-tokens)

---

## Pre-Release Checklist

Before starting a new release, ensure:

- [ ] All code changes are committed and pushed to GitHub
- [ ] Tests pass locally (especially on Mac if Mac-specific changes)
- [ ] README.md and README.zh-CN.md are up to date
- [ ] CHANGELOG.md is updated with new version changes
- [ ] Python dependencies in src/requirements.txt are current
- [ ] No uncommitted changes (`git status` should be clean)

---

## Version Bump Process

### 1. Decide Version Number

Follow semantic versioning (MAJOR.MINOR.PATCH):
- **MAJOR**: Breaking changes (e.g., 1.0.0 → 2.0.0)
- **MINOR**: New features, backward compatible (e.g., 0.3.0 → 0.4.0)
- **PATCH**: Bug fixes, backward compatible (e.g., 0.3.3 → 0.3.4)

### 2. Update Version in Files

Update the version number in these files:

#### package.json
```json
"version": "0.X.Y",
```

#### README.md (English)
Search and replace version numbers in:
- Download links: `stata-mcp-0.X.Y.vsix`
- Installation commands: `path/to/stata-mcp-0.X.Y.vsix`

#### README.zh-CN.md (Chinese)
Search and replace version numbers in:
- Download links: `stata-mcp-0.X.Y.vsix`
- Installation commands: `path/to/stata-mcp-0.X.Y.vsix`

### 3. Update CHANGELOG.md

Add a new section at the top:

```markdown
## [0.X.Y] - YYYY-MM-DD

### Added
- New feature descriptions

### Changed
- Changed functionality descriptions

### Fixed
- Bug fix descriptions

### Removed
- Removed feature descriptions
```

---

## Building the Package

### 1. Build VSIX Package

```bash
npm run package
```

This will:
- Run webpack to bundle the extension
- Create `stata-mcp-0.X.Y.vsix` file

### 2. Verify Build

Check the build output:
```bash
ls -lh stata-mcp-0.X.Y.vsix
```

Expected size: ~2.6-2.8 MB

### 3. Test Locally (Optional but Recommended)

Install and test the VSIX locally:

**VS Code:**
```bash
code --install-extension stata-mcp-0.X.Y.vsix
```

**Cursor:**
```bash
cursor --install-extension stata-mcp-0.X.Y.vsix
```

Test basic functionality:
- MCP server starts
- Run Stata commands
- Graph export works
- No errors in logs

---

## Publishing Workflow

### Step 1: Commit and Push

```bash
git add package.json README.md README.zh-CN.md CHANGELOG.md
git commit -m "chore: bump version to 0.X.Y"
git push
```

### Step 2: Create GitHub Release

```bash
gh release create v0.X.Y stata-mcp-0.X.Y.vsix \
  --title "v0.X.Y - Brief Description" \
  --notes "## What's Changed

### Feature/Fix Category
- Description of changes

**Full Changelog**: https://github.com/hanlulong/stata-mcp/compare/v0.PREV.VER...v0.X.Y"
```

**Important**:
- Use `v0.X.Y` format for tag (with 'v' prefix)
- Attach the VSIX file to the release
- Write clear, user-friendly release notes

### Step 3: Publish to VS Marketplace

```bash
vsce publish --packagePath stata-mcp-0.X.Y.vsix
```

Expected output:
```
INFO  Publishing 'DeepEcon.stata-mcp v0.X.Y'...
INFO  Extension URL: https://marketplace.visualstudio.com/items?itemName=DeepEcon.stata-mcp
DONE  Published DeepEcon.stata-mcp v0.X.Y.
```

**Note**: If you see "already exists" error, the version is already published. You cannot republish the same version.

### Step 4: Publish to Open VSX Registry

```bash
ovsx publish stata-mcp-0.X.Y.vsix -p YOUR_TOKEN_HERE
```

Expected output:
```
🚀  Published DeepEcon.stata-mcp v0.X.Y
```

**Common Issues**:
- Invalid character in description: Ensure package.json description has no newlines
- Use hyphen/space instead of `\n` for multi-line descriptions

---

## Post-Release Tasks

### 1. Verify Publications

Check all platforms:

- **GitHub**: https://github.com/hanlulong/stata-mcp/releases
- **VS Marketplace**: https://marketplace.visualstudio.com/items?itemName=DeepEcon.stata-mcp
- **Open VSX**: https://open-vsx.org/extension/DeepEcon/stata-mcp

### 2. Clean Up Old VSIX Files

Keep only the latest VSIX in the repository:

```bash
rm stata-mcp-0.OLD.*.vsix
```

Commit the cleanup:
```bash
git add -A
git commit -m "chore: remove old VSIX builds"
git push
```

### 3. Test Installation from Marketplaces

**From VS Marketplace:**
```bash
code --install-extension DeepEcon.stata-mcp
```

**From Open VSX (for Cursor users):**
Should auto-update or allow manual install through UI

### 4. Update Documentation (if needed)

If the release includes major changes, consider updating:
- GitHub repository description
- Social media announcements
- User documentation

---

## Troubleshooting

### Problem: "Invalid character in description" (Open VSX)

**Cause**: Open VSX doesn't accept newline characters in package.json description

**Fix**:
```json
// ❌ Bad
"description": "Line 1\nLine 2"

// ✅ Good
"description": "Line 1 - Line 2"
```

### Problem: "Version already exists" (VS Marketplace)

**Cause**: You're trying to publish a version that's already published

**Fix**:
- You cannot republish the same version
- Bump to the next patch version (e.g., 0.3.3 → 0.3.4)
- Delete the remote release if it was just created and hasn't been downloaded

### Problem: VSIX build fails

**Check**:
```bash
# Verify Node.js and npm are installed
node --version
npm --version

# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install

# Try building again
npm run package
```

### Problem: Git push fails

**Check**:
```bash
# Check remote status
git remote -v

# Fetch latest changes
git fetch origin

# If behind, pull first
git pull --rebase origin main

# Then push
git push
```

### Problem: gh command not found

**Install GitHub CLI**:
```bash
# macOS
brew install gh

# Then authenticate
gh auth login
```

### Problem: vsce command not found

**Install vsce**:
```bash
npm install -g @vscode/vsce
```

### Problem: ovsx command not found

**Install ovsx**:
```bash
npm install -g ovsx
```

---

## Credentials and Tokens

### Stored Credentials Location

**All publishing tokens are securely stored at**:
```
~/.stata-mcp-credentials/tokens.env
```

This file contains:
- `VSCE_PAT`: VS Marketplace (Azure DevOps) Personal Access Token
- `OVSX_PAT`: Open VSX Registry Personal Access Token

**File permissions**: 600 (read/write for owner only)

**Usage in commands**:
```bash
# Load credentials from file
source ~/.stata-mcp-credentials/tokens.env

# Then use in publishing commands
vsce publish --packagePath stata-mcp-0.X.Y.vsix -p $VSCE_PAT
ovsx publish stata-mcp-0.X.Y.vsix -p $OVSX_PAT
```

### VS Marketplace Token (VSCE_PAT)

**Where to get**:
1. Go to https://dev.azure.com/YOUR_ORG/_usersSettings/tokens
2. Create a new Personal Access Token
3. Scopes: Marketplace (Publish)

**Note**: Token is stored in `~/.stata-mcp-credentials/tokens.env`

### Open VSX Token (OVSX_PAT)

**Where to get new token**:
1. Go to https://open-vsx.org/user-settings/tokens
2. Create a new access token
3. Copy and save securely

**Note**: Token is stored in `~/.stata-mcp-credentials/tokens.env`

### GitHub Token

**Managed by**: GitHub CLI (`gh`)

**Authenticate**:
```bash
gh auth login
```

Follow the prompts to authenticate with your GitHub account.

---

## Quick Reference Commands

### Complete Release Flow (Copy-Paste Template)

```bash
# 1. Update version in package.json, READMEs, CHANGELOG.md manually

# 2. Build package
npm run package

# 3. Verify build
ls -lh stata-mcp-*.vsix

# 4. Test locally (optional but recommended)
cursor --install-extension stata-mcp-0.X.Y.vsix
# Verify: MCP server starts, basic functionality works

# 5. Commit and push
git add package.json README.md README.zh-CN.md CHANGELOG.md
git commit -m "chore: bump version to 0.X.Y"
git push

# 6. Create GitHub release
gh release create v0.X.Y stata-mcp-0.X.Y.vsix \
  --title "v0.X.Y - Description" \
  --notes "Release notes here"

# 7. Load credentials
source ~/.stata-mcp-credentials/tokens.env

# 8. Publish to VS Marketplace
vsce publish --packagePath stata-mcp-0.X.Y.vsix -p $VSCE_PAT

# 9. Publish to Open VSX
ovsx publish stata-mcp-0.X.Y.vsix -p $OVSX_PAT

# 10. Clean up old builds (if any)
rm stata-mcp-0.OLD.*.vsix

# 11. Verify all platforms
echo "Check:"
echo "- https://github.com/hanlulong/stata-mcp/releases"
echo "- https://marketplace.visualstudio.com/items?itemName=DeepEcon.stata-mcp"
echo "- https://open-vsx.org/extension/DeepEcon/stata-mcp"
```

---

## Emergency Rollback

If a release has critical bugs:

### 1. Quick Fix Release

Bump to next patch version and release immediately with the fix.

### 2. Deprecate Release (GitHub)

Mark the release as a pre-release or delete if no downloads yet:
```bash
# Edit release to mark as pre-release
gh release edit v0.X.Y --prerelease

# Or delete (only if just released)
gh release delete v0.X.Y
```

### 3. Note About Marketplaces

**Important**: Once published to VS Marketplace and Open VSX, you cannot unpublish. You can only:
- Publish a new fixed version
- Users on older versions should update

---

## Best Practices

1. **Always test locally** before publishing
2. **Write clear release notes** - users read these
3. **Use semantic versioning** - helps users understand impact
4. **Keep CHANGELOG.md updated** - good documentation practice
5. **Don't rush releases** - take time to test thoroughly
6. **Coordinate updates** - all 3 platforms (GitHub, VS Marketplace, Open VSX) should have same version
7. **Clean up after release** - remove old VSIX files to keep repo tidy
8. **Document breaking changes** clearly in release notes

---

## Version History Quick Reference

| Version | Date | Key Changes |
|---------|------|-------------|
| 0.3.3 | 2025-10-21 | Fix Mac graph export crash, dock icon suppression |
| 0.3.2 | 2025-10-21 | Fix Open VSX description format |
| 0.3.1 | 2025-10-21 | Add DeepEcon.ai branding |
| 0.3.0 | 2025-10-14 | Unicode support, conditional graph processing |
| 0.2.9 | 2025-10-14 | cls command fix, MCP initialization fix |

---

**Last Updated**: October 21, 2025
**Maintained By**: Han Lulong
**Repository**: https://github.com/hanlulong/stata-mcp
